<?php

    if (defined('LOADED') == false)
        exit;

    define('ASSET_PARAMETER_RAND_URL',   'rand');
    define('ASSET_PARAMETER_UID_URL',    'uid');
    define('ASSET_PARAMETER_LOAD_LANG',  'lang');