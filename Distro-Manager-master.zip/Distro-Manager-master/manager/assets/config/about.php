<?php

    if (defined('LOADED') == false)
        exit;

    return [
        'build_at' => 1517152021,
        'name' => 'Manager',
        'author' => 'IzeroCs',
        'version' => '3.5.4',
        'is_beta' => true,
        'email' => 'Izero.Cs@gmail.com',
        'fb_link' => 'https://facebook.com/IzeroCs',
        'fb_title' => 'fb.com/IzeroCs',
        'git_link' => 'https://github.com/IzeroCs/Manager',
        'git_title' => 'IzeroCs/Manager',
        'phone' => '+841685929323',
        'create_at' => 1434468025,
        'upgrade_at' => 0,
        'check_at' => 1517150066,
    ];

?>