<?php

    if (defined('LOADED') == false)
        exit;

    return [
        'title_page'      => 'Danh sách dữ liệu',
        'empty_list_data' => 'Không có dữ liệu',

        'action_multi' => [
            'delete' => 'Xóa'
        ],

        'alert' => [
            'data_is_empty_not_view' => 'Không có dữ liệu để xem'
        ]
    ];

?>