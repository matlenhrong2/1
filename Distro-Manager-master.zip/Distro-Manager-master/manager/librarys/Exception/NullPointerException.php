<?php

    namespace Librarys\Exception;

    class NullPointerException extends RuntimeException
    {

    }
