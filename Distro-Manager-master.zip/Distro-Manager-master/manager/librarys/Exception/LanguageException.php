<?php

    namespace Librarys\Exception;

    class LanguageException extends RuntimeException
    {

    }
